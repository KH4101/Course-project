# My Game Collection

A small full-stack CRUD app for tracking the video games you own: platform,
genre, release year, what you paid, condition, whether you've beaten it, and
your own rating/notes.

**Stack:** Flask (Python) + SQLite for the backend/API, vanilla HTML/CSS/JS
for the frontend — no build step, no Node required.

## Run it

```bash
# 1. (recommended) create a virtual environment
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. install the one dependency
pip install -r requirements.txt

# 3. run it
python app.py
```

Open **http://127.0.0.1:5000** in your browser.

A `games.db` SQLite file is created automatically the first time you run it,
in the same folder as `app.py`. Delete that file any time to start fresh.

## How it's built

```
game-collection/
  app.py              # Flask app: all routes + SQLite access, no ORM
  requirements.txt
  templates/
    index.html         # single page
  static/
    style.css
    app.js              # fetch() calls to the API, renders the grid + modal
  games.db             # created on first run (not in the repo)
```

### API

| Method | Route              | Does                                  |
|--------|--------------------|----------------------------------------|
| GET    | `/api/games`       | list games (supports `?search=`, `?platform=`, `?completed=0/1`, `?sort=`, `?dir=`) |
| POST   | `/api/games`       | create a game (`title` required)       |
| GET    | `/api/games/<id>`  | get one game                           |
| PUT    | `/api/games/<id>`  | update a game (partial updates OK)     |
| DELETE | `/api/games/<id>`  | delete a game                          |
| GET    | `/api/stats`       | totals for the header (count, $ spent, platform list) |

The frontend is a single page that calls this API with `fetch()` — there's
no page reload for any action.

## What I'd extend first

Roughly in order of "most value for least effort":

1. **Cover art.** Add an `IGDB` or `RAWG` API lookup by title on save, and
   store the returned cover image URL. Turns the grid from a spreadsheet
   into something that actually looks like a shelf of games.
2. **Multi-user / auth.** Right now it's single-user, no login. Adding
   Flask-Login + a `users` table with a foreign key on `games.user_id`
   would let you deploy it for family/friends without everyone sharing one
   collection.
3. **Sorting/filtering as saved views** — e.g. "Backlog" (not completed,
   sorted by purchase date) as a one-click preset instead of re-setting the
   filters each time.
4. **Bulk import.** A CSV upload endpoint so you can dump in an existing
   spreadsheet collection instead of adding games one by one.
5. **Wishlist flag.** A boolean for "want to buy" vs "own" so the same app
   covers your backlog *and* your shopping list, with a toggle to move an
   item from one to the other.
6. **Deploy it properly.** Swap `app.run(debug=True)` for a real WSGI
   server (gunicorn) behind something like Fly.io or Render, and switch
   SQLite for Postgres if more than one person will hit it at once —
   SQLite is fine for a single local user but not for concurrent writers.

If you want, I can build out any of these next — the cover-art lookup and
the CSV import are both pretty quick wins.
