"""
Video Game Collection Tracker
A small Flask + SQLite CRUD app.

Run with:  python app.py
Then open: http://127.0.0.1:5000
"""

import sqlite3
from pathlib import Path

from flask import Flask, g, jsonify, render_template, request

DB_PATH = Path(__file__).parent / "games.db"

app = Flask(__name__)


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS games (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            title         TEXT NOT NULL,
            platform      TEXT,
            genre         TEXT,
            release_year  INTEGER,
            purchase_date TEXT,
            price_paid    REAL,
            condition     TEXT DEFAULT 'Good',
            completed     INTEGER DEFAULT 0,
            rating        INTEGER,
            notes         TEXT,
            created_at    TEXT DEFAULT (datetime('now'))
        )
        """
    )
    db.commit()
    db.close()


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

REQUIRED_FIELDS = ["title"]
ALLOWED_FIELDS = {
    "title", "platform", "genre", "release_year", "purchase_date",
    "price_paid", "condition", "completed", "rating", "notes",
}


def clean_payload(data: dict) -> dict:
    """Keep only known fields, coerce types, ignore anything else."""
    cleaned = {}
    for key in ALLOWED_FIELDS:
        if key not in data:
            continue
        value = data[key]
        if key == "release_year" and value not in (None, ""):
            value = int(value)
        elif key == "price_paid" and value not in (None, ""):
            value = float(value)
        elif key == "rating" and value not in (None, ""):
            value = int(value)
        elif key == "completed":
            value = 1 if value in (True, 1, "1", "true", "True") else 0
        cleaned[key] = value
    return cleaned


def row_to_dict(row: sqlite3.Row) -> dict:
    d = dict(row)
    d["completed"] = bool(d["completed"])
    return d


# ---------------------------------------------------------------------------
# Frontend
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


# ---------------------------------------------------------------------------
# API: list + create
# ---------------------------------------------------------------------------

@app.route("/api/games", methods=["GET"])
def list_games():
    db = get_db()

    query = "SELECT * FROM games WHERE 1=1"
    params = []

    search = request.args.get("search")
    if search:
        query += " AND (title LIKE ? OR genre LIKE ? OR notes LIKE ?)"
        like = f"%{search}%"
        params += [like, like, like]

    platform = request.args.get("platform")
    if platform:
        query += " AND platform = ?"
        params.append(platform)

    completed = request.args.get("completed")
    if completed in ("0", "1"):
        query += " AND completed = ?"
        params.append(int(completed))

    sort = request.args.get("sort", "created_at")
    direction = "DESC" if request.args.get("dir", "desc") == "desc" else "ASC"
    if sort not in {"title", "platform", "release_year", "price_paid", "rating", "created_at"}:
        sort = "created_at"
    query += f" ORDER BY {sort} {direction}"

    rows = db.execute(query, params).fetchall()
    return jsonify([row_to_dict(r) for r in rows])


@app.route("/api/games", methods=["POST"])
def create_game():
    data = request.get_json(silent=True) or {}
    missing = [f for f in REQUIRED_FIELDS if not data.get(f)]
    if missing:
        return jsonify({"error": f"Missing required field(s): {', '.join(missing)}"}), 400

    payload = clean_payload(data)
    columns = ", ".join(payload.keys())
    placeholders = ", ".join("?" for _ in payload)
    db = get_db()
    cur = db.execute(
        f"INSERT INTO games ({columns}) VALUES ({placeholders})",
        list(payload.values()),
    )
    db.commit()
    new_row = db.execute("SELECT * FROM games WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(row_to_dict(new_row)), 201


# ---------------------------------------------------------------------------
# API: single game (read / update / delete)
# ---------------------------------------------------------------------------

@app.route("/api/games/<int:game_id>", methods=["GET"])
def get_game(game_id):
    db = get_db()
    row = db.execute("SELECT * FROM games WHERE id = ?", (game_id,)).fetchone()
    if row is None:
        return jsonify({"error": "Game not found"}), 404
    return jsonify(row_to_dict(row))


@app.route("/api/games/<int:game_id>", methods=["PUT", "PATCH"])
def update_game(game_id):
    db = get_db()
    existing = db.execute("SELECT * FROM games WHERE id = ?", (game_id,)).fetchone()
    if existing is None:
        return jsonify({"error": "Game not found"}), 404

    data = request.get_json(silent=True) or {}
    payload = clean_payload(data)
    if not payload:
        return jsonify({"error": "No valid fields provided"}), 400

    set_clause = ", ".join(f"{key} = ?" for key in payload)
    db.execute(
        f"UPDATE games SET {set_clause} WHERE id = ?",
        list(payload.values()) + [game_id],
    )
    db.commit()
    updated = db.execute("SELECT * FROM games WHERE id = ?", (game_id,)).fetchone()
    return jsonify(row_to_dict(updated))


@app.route("/api/games/<int:game_id>", methods=["DELETE"])
def delete_game(game_id):
    db = get_db()
    existing = db.execute("SELECT * FROM games WHERE id = ?", (game_id,)).fetchone()
    if existing is None:
        return jsonify({"error": "Game not found"}), 404
    db.execute("DELETE FROM games WHERE id = ?", (game_id,))
    db.commit()
    return "", 204


# ---------------------------------------------------------------------------
# API: small stats endpoint (used by the dashboard header)
# ---------------------------------------------------------------------------

@app.route("/api/stats", methods=["GET"])
def stats():
    db = get_db()
    total = db.execute("SELECT COUNT(*) AS c FROM games").fetchone()["c"]
    completed = db.execute("SELECT COUNT(*) AS c FROM games WHERE completed = 1").fetchone()["c"]
    total_spent = db.execute("SELECT COALESCE(SUM(price_paid), 0) AS s FROM games").fetchone()["s"]
    platforms = db.execute(
        "SELECT DISTINCT platform FROM games WHERE platform IS NOT NULL AND platform != '' ORDER BY platform"
    ).fetchall()
    return jsonify({
        "total_games": total,
        "completed_games": completed,
        "total_spent": round(total_spent, 2),
        "platforms": [p["platform"] for p in platforms],
    })


if __name__ == "__main__":
    init_db()
    app.run(debug=True, port=5000)
