const API = "/api/games";

const grid = document.getElementById("gameGrid");
const emptyState = document.getElementById("emptyState");
const statsEl = document.getElementById("stats");
const searchInput = document.getElementById("searchInput");
const platformFilter = document.getElementById("platformFilter");
const completedFilter = document.getElementById("completedFilter");
const sortSelect = document.getElementById("sortSelect");

const modalOverlay = document.getElementById("modalOverlay");
const modalTitle = document.getElementById("modalTitle");
const gameForm = document.getElementById("gameForm");

let debounceTimer = null;

// ---------------------------------------------------------------------------
// Data fetching
// ---------------------------------------------------------------------------

async function fetchGames() {
  const params = new URLSearchParams();
  if (searchInput.value.trim()) params.set("search", searchInput.value.trim());
  if (platformFilter.value) params.set("platform", platformFilter.value);
  if (completedFilter.value) params.set("completed", completedFilter.value);
  params.set("sort", sortSelect.value);

  const res = await fetch(`${API}?${params.toString()}`);
  const games = await res.json();
  renderGrid(games);
}

async function fetchStats() {
  const res = await fetch("/api/stats");
  const data = await res.json();
  statsEl.innerHTML = `
    <span><b>${data.total_games}</b> games</span>
    <span><b>${data.completed_games}</b> completed</span>
    <span><b>$${data.total_spent.toFixed(2)}</b> spent</span>
  `;

  const current = platformFilter.value;
  platformFilter.innerHTML = '<option value="">All platforms</option>' +
    data.platforms.map(p => `<option value="${escapeAttr(p)}">${escapeHtml(p)}</option>`).join("");
  platformFilter.value = current;
}

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------

function renderGrid(games) {
  grid.innerHTML = "";
  emptyState.hidden = games.length > 0;

  for (const game of games) {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <div class="card-header">
        <h3 class="card-title">${escapeHtml(game.title)}</h3>
        <span class="badge ${game.completed ? "completed" : ""}">
          ${game.completed ? "Completed" : "In backlog"}
        </span>
      </div>
      <div class="card-meta">
        ${game.platform ? `<span>🖥️ ${escapeHtml(game.platform)}</span>` : ""}
        ${game.genre ? `<span>🏷️ ${escapeHtml(game.genre)}</span>` : ""}
        ${game.release_year ? `<span>📅 ${game.release_year}</span>` : ""}
        ${game.price_paid != null ? `<span>💵 $${Number(game.price_paid).toFixed(2)} · ${escapeHtml(game.condition || "")}</span>` : ""}
        ${game.rating ? `<span class="rating">⭐ ${game.rating}/10</span>` : ""}
      </div>
      ${game.notes ? `<div class="card-notes">${escapeHtml(game.notes)}</div>` : ""}
      <div class="card-actions">
        <button class="secondary" data-action="edit" data-id="${game.id}">Edit</button>
        <button class="secondary" data-action="delete" data-id="${game.id}">Delete</button>
      </div>
    `;
    grid.appendChild(card);
  }
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}
function escapeAttr(str) {
  return escapeHtml(str).replace(/"/g, "&quot;");
}

// ---------------------------------------------------------------------------
// Modal / form
// ---------------------------------------------------------------------------

function openModal(game = null) {
  gameForm.reset();
  document.getElementById("gameId").value = game?.id ?? "";
  modalTitle.textContent = game ? "Edit Game" : "Add Game";

  if (game) {
    document.getElementById("title").value = game.title ?? "";
    document.getElementById("platform").value = game.platform ?? "";
    document.getElementById("genre").value = game.genre ?? "";
    document.getElementById("release_year").value = game.release_year ?? "";
    document.getElementById("purchase_date").value = game.purchase_date ?? "";
    document.getElementById("price_paid").value = game.price_paid ?? "";
    document.getElementById("condition").value = game.condition ?? "Good";
    document.getElementById("rating").value = game.rating ?? "";
    document.getElementById("completed").checked = !!game.completed;
    document.getElementById("notes").value = game.notes ?? "";
  }

  modalOverlay.hidden = false;
  document.getElementById("title").focus();
}

function closeModal() {
  modalOverlay.hidden = true;
}

document.getElementById("addGameBtn").addEventListener("click", () => openModal());
document.getElementById("cancelBtn").addEventListener("click", closeModal);
modalOverlay.addEventListener("click", (e) => {
  if (e.target === modalOverlay) closeModal();
});

gameForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const id = document.getElementById("gameId").value;
  const payload = {
    title: document.getElementById("title").value.trim(),
    platform: document.getElementById("platform").value.trim(),
    genre: document.getElementById("genre").value.trim(),
    release_year: document.getElementById("release_year").value || null,
    purchase_date: document.getElementById("purchase_date").value || null,
    price_paid: document.getElementById("price_paid").value || null,
    condition: document.getElementById("condition").value,
    rating: document.getElementById("rating").value || null,
    completed: document.getElementById("completed").checked,
    notes: document.getElementById("notes").value.trim(),
  };

  const url = id ? `${API}/${id}` : API;
  const method = id ? "PUT" : "POST";

  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    alert(err.error || "Something went wrong saving that game.");
    return;
  }

  closeModal();
  await Promise.all([fetchGames(), fetchStats()]);
});

// ---------------------------------------------------------------------------
// Grid click delegation (edit / delete)
// ---------------------------------------------------------------------------

grid.addEventListener("click", async (e) => {
  const btn = e.target.closest("button[data-action]");
  if (!btn) return;
  const id = btn.dataset.id;

  if (btn.dataset.action === "edit") {
    const res = await fetch(`${API}/${id}`);
    const game = await res.json();
    openModal(game);
  }

  if (btn.dataset.action === "delete") {
    if (!confirm("Delete this game from your collection?")) return;
    await fetch(`${API}/${id}`, { method: "DELETE" });
    await Promise.all([fetchGames(), fetchStats()]);
  }
});

// ---------------------------------------------------------------------------
// Filters
// ---------------------------------------------------------------------------

searchInput.addEventListener("input", () => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(fetchGames, 250);
});
platformFilter.addEventListener("change", fetchGames);
completedFilter.addEventListener("change", fetchGames);
sortSelect.addEventListener("change", fetchGames);

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------

fetchGames();
fetchStats();
